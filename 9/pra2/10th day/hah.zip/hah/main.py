from scrapy import cmdline

#执行一个爬虫
cmdline.execute('scrapy crawl xdl'.split())