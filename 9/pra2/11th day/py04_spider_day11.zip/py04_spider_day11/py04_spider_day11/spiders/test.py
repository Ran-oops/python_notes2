'''
dic = {"one":1,"two":2}

for k,v in dic.items():
    print(k,v)
'''
a = 10
def foo(x):
    print(x)

foo(a)